def bl_init() :
    print("0x000001 BOOT SUCCESS")
    print("0x000002 BL-LD PYTHON SUCCESS")